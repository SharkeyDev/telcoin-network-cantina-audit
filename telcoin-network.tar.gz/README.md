This monorepo contains all the repositories for the Telcoin competition
