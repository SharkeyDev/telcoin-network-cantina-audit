# Chain Configs

This directory comtins the genesis and general configurations for testnet and mainnet.
These will be built into the telcoin-network binary for use with the --chain command.

NOTE: at the time of writing these are just placeholders and are NOT the actual network configs.
