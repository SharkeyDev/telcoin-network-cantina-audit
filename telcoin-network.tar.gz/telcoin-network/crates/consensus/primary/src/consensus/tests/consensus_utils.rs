//! Utils for consensus tests

pub const NUM_SUB_DAGS_PER_SCHEDULE: u32 = 100;
