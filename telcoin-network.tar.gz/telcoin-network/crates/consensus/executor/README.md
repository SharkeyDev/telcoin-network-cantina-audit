# TN Executor

The adaptor for consensus layer to send and receive execution data.
