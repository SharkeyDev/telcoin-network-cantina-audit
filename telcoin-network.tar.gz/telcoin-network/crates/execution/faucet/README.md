# TN Faucet

The infrastructure for running the Telcoin Network (Adiri) testnet faucet.
